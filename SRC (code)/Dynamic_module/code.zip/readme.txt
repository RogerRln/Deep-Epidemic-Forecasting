
Step 1: Unzip code

Step 2: python ./SRC/model.py > results.txt
    - This will get results for 1-wk ahead.
    - Average results will be at the bottom of results.txt in this order:
        US National, California, Georgia, Texas, Pennsylvania
    - If you want 2-wk ahead, change line 241 to =2

Step 3: Run subset of our proposed model:
    - Comment out line 248, and uncomment line 247
    