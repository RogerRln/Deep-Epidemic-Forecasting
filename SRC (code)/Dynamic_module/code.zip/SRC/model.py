import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch._C import dtype
import torch.optim as optim
import pickle
import matplotlib.pyplot as plt
from epiweeks import Week, Year
import torch.nn.functional as F


class Encoder(nn.Module):
    """
    Module to embed sequence, use only RNN
    """
    def __init__(
        self,
        dim_seq_in: int = 5,
        rnn_out: int = 40,
        n_layers: int = 1,
        bidirectional: bool = False,
        layers = [10,5,2],
        clustering=False,
    ) -> None:
        """
        param dim_seq_in: Dimensionality of input vector (no. of features)
        param dim_out: Dimensionality of output vector
        param dim_region: Dimensions of region vector
        param rnn_out: output dimension for rnn
        """
        super(Encoder, self).__init__()

        self.dim_seq_in = dim_seq_in
        self.rnn_out = rnn_out
        self.bidirectional = bidirectional

        self.rnn = nn.GRU(
            input_size=self.dim_seq_in,
            hidden_size=self.rnn_out // 2 if self.bidirectional else self.rnn_out,
            bidirectional=bidirectional,
            num_layers=n_layers,
            # dropout=0.3,
        )
        self.initHidden()
        self.clustering=clustering
        if self.clustering:
            # clustering layer
            n_centroids=4
            self.cluster_layer = nn.Parameter(torch.Tensor(n_centroids, self.rnn_out))
            torch.nn.init.xavier_normal_(self.cluster_layer.data)
            self.alpha = 1
    
    def initHidden(self):
        """
            https://discuss.pytorch.org/t/initializing-rnn-gru-and-lstm-correctly/23605
        """  
        for m in self.modules():
            if type(m) in [nn.GRU, nn.LSTM, nn.RNN]:
                for name, param in m.named_parameters():
                    if 'weight_ih' in name:
                        torch.nn.init.xavier_uniform_(param.data)
                    elif 'weight_hh' in name:
                        torch.nn.init.orthogonal_(param.data)
                    elif 'bias' in name:
                        param.data.fill_(0)

    def forward(self, seqs, mask):
        """
            @returns: latent representation of sequence, categorical reconstruction
        """
        seqs = seqs.transpose(1, 0)  # transpose to have ready for GRU
        # Take last output from GRU
        latent_seqs = self.rnn(seqs)[0]  # index 0 obtains all hidden states
        latent_seqs = latent_seqs*mask
        latent_seqs = latent_seqs.sum(0)  # NOTE: change when doing attention
        q=None
        if self.clustering:
            # clustering
            q = 1.0 / (1.0 + torch.sum(
                torch.pow(latent_seqs.unsqueeze(1) - self.cluster_layer, 2), 2) / self.alpha)
            q = q.pow((self.alpha + 1.0) / 2.0)
            q = (q.t() / torch.sum(q, 1)).t()
        
        return latent_seqs, q
    

def target_distribution(q):
    weight = q**2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()


class LinearAutoEncoder(nn.Module):
    """
        Autoencoder for regional embedding
        Use softmax if output is categorical (e.g. one hot encoding)
    """
    def __init__(
        self,
        dim_in: int = 3,
        dim_hidden_ae: int = 16,
        categorical=False,
        clustering=False,
    ) -> None:
        super(LinearAutoEncoder, self).__init__()
      
        self.ae_in = nn.Sequential(*[nn.Linear(dim_in,128),nn.Linear(128,dim_hidden_ae)])
        self.ae_out = nn.Sequential(*[nn.Linear(dim_hidden_ae,128),nn.Linear(128,dim_in)])
        self.sigmoid = nn.Sigmoid()
        self.categorical = categorical
        if self.categorical:
            self.softmax = nn.Softmax(dim=1)
        self.clustering=clustering
        if self.clustering:
            # clustering layer
            n_centroids=4
            self.cluster_layer = nn.Parameter(torch.Tensor(n_centroids, dim_hidden_ae))
            torch.nn.init.xavier_normal_(self.cluster_layer.data)
            self.alpha = 1

    def forward(self, input):
        embed = self.sigmoid(self.ae_in(input))
        if self.categorical:
            # print(self.ae_out(embed).shape)
            recon = self.softmax(self.ae_out(embed))
        else:
            recon = self.ae_out(embed)
        q=None
        if self.clustering:
            # clustering
            q = 1.0 / (1.0 + torch.sum(
                torch.pow(embed.unsqueeze(1) - self.cluster_layer, 2), 2) / self.alpha)
            q = q.pow((self.alpha + 1.0) / 2.0)
            q = (q.t() / torch.sum(q, 1)).t()
        return embed, recon, q


class AttDecoder(nn.Module):
    """
    Decode with temporal attention
    NOTE: attention to be implemented
    """

    def __init__(
        self,
        dim_in: int = 5,
        dim_encoder: int = 32, # this is from encoder, dim of hidden state
        dim_region_emb: int = 3,
        rnn_out: int = 40,
        dim_out: int = 50,
        n_layers: int = 1,
        bidirectional: bool = False,
    ) -> None:
        """
        param dim_in: Dimensionality of input vector (concat of embeddings)
        param dim_out: Dimensionality of output vector
        param rnn_out: output dimension for rnn
        """
        super(AttDecoder, self).__init__()

        self.dim_in = dim_in
        self.dim_region_emb = dim_region_emb
        self.rnn_out = rnn_out
        self.dim_out = dim_out
        self.bidirectional = bidirectional
        self.dim_encoder = dim_encoder

        # check attention from https://github.com/Zhenye-Na/DA-RNN#attention-mechanism

        self.rnn = nn.GRU(
            input_size=self.dim_in,
            hidden_size=self.rnn_out // 2 if self.bidirectional else self.rnn_out,
            bidirectional=bidirectional,
            num_layers=n_layers,
        )
        
        self.out_layer = [
            # nn.Linear(
            #     in_features=self.rnn_out + self.dim_region_emb, out_features=32
            # ),
            nn.Linear(
                # in_features=self.dim_encoder, out_features=64
                # in_features=self.dim_encoder + self.dim_in, out_features=64
                in_features=192, out_features=64
            ),
            nn.BatchNorm1d(num_features=64,affine=True),
            nn.LeakyReLU(),
            nn.Dropout(p=0.2),
            nn.Linear(
                in_features=64, out_features=32
            ),
            nn.BatchNorm1d(num_features=32,affine=True),
            nn.LeakyReLU(),
            nn.Dropout(p=0.2),
            nn.Linear(
                in_features=32, out_features=32
            ),
            nn.LeakyReLU(),
            nn.Linear(
                in_features=32, out_features=self.dim_out
            ),
            nn.ReLU(),
        ]
        self.out_layer = nn.Sequential(*self.out_layer)

    def forward(self, embed, encoder_hidden, region_emb, k_ahead):
        """
            param region_emb: region is very important, incorporating it twice 
                                (as input to decoder and output layer)
            param embed: embedding from other modules, (batch,dim_in)
            @returns: latent representation of sequence, categorical reconstruction
        """
        # TODO: attention
        context = encoder_hidden  
        seqs = torch.cat([embed, context], dim=1).transpose(1, 0)  # transpose to have ready for GRU
        # TODO: GRU
        # NOTE: not using GRU, transpose back
        latent_seqs = seqs.transpose(1, 0)  # transpose to have ready for GRU
        out = self.out_layer(latent_seqs)
        return out.unsqueeze(1)


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
float_tensor = (
    torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor
)



"""
    Input parameters
"""
ew=Week.fromstring('202040')  # prediction week
since_ew=Week.fromstring('202020')  # prediction week
data_ew = Week.thisweek(system="CDC") - 1  # -1 because we have data for the previous (ending) week
path='./data/EW'+data_ew.cdcformat()
datapath = path+'/train_data_weekly_noscale_vEW'+data_ew.cdcformat()+'.csv'
datapath = path+'/train_data_weekly_vEW'+data_ew.cdcformat()+'.csv'
df = pd.read_csv(datapath)
df_static = pd.read_csv('./data/static/train_static_states.csv')
wk_ahead=1 # change here for future target
SCALE_TARGET=True
TRAIN=True
start_ew='202030'
end_ew='202042'

# opt='GRU'
opt='Our'

if opt=='GRU':
    MODEL_PATH="./mods/gru"
    MODE='OnlyGRU'
else:
    MODE='Our'
    MODEL_PATH="./mods/model"

mae_dict={} # save here mae for all weeks
"""
    Select regions
"""
# use all states:
city_idx={}
states=0
for r in df['region'].unique()[:-1]:
    city_idx[r] = states
    states+=1
"""
    Select columns for training
"""
include_col=['retail_and_recreation_percent_change_from_baseline','grocery_and_pharmacy_percent_change_from_baseline','parks_percent_change_from_baseline','transit_stations_percent_change_from_baseline','workplaces_percent_change_from_baseline','residential_percent_change_from_baseline','positiveIncrease','negativeIncrease','totalTestResultsIncrease','onVentilatorCurrently','inIcuCurrently','recovered','hospitalizedIncrease','death_jhu_incidence','dex_a','apple_mobility','Number of Facilities Reporting','CLI Percent of Total Visits']  #no covidnet
include_col_static=['NumAdultsChronicCond','PercAdultsChronicCond','MedianAge2010','DiabetesPercentage','HeartDiseaseMortality','StrokeMortality','Smokers_Percentage','RespMortalityRate2014','TotalM_D__s_TotNon_FedandFed2017','x_Hospitals','x_ICU_beds','SVIPercentile','PopulationEstimate65_2017','MaskNever','MaskRare','MaskSome','MaskFreq','MaskAlways']

def train_week(ew,MODE):
    """
        Create data arrays and tensors
    """

    def one_hot(dim, idx):
        ans = np.zeros(dim, dtype="float32")
        ans[idx] = 1.0
        return ans

    x_train = np.array(
        [
            np.array(df[(df["epiweek"] < ew.week) & (df["epiweek"] >= since_ew.week) & (df["region"] == r)][include_col])
            for r in city_idx.keys()
        ],
        dtype="float32",
    )

    # aka metadata of each region
    static_train = np.array(
        [
            np.array(df_static[(df_static['STATEAbbrv'] == r)][include_col_static])
            for r in city_idx.keys()
        ],
        dtype="float32",
    ).squeeze()

    if len(city_idx)==1:
        static_train=static_train.reshape(-1,1)

    y_train = np.array(
        [
            np.array(df[(df["epiweek"] < ew.week) & (df["epiweek"] >= since_ew.week) & (df["region"] == r)]["target_death"])
            # for week in train_seasons
            for r in city_idx.keys()
        ],
        dtype="float32",
    )

    # region one hot encoding
    region_train = np.array(
        [
            np.stack(
                df[(df["epiweek"] < ew.week) & (df["epiweek"] >= since_ew.week) & (df["region"] == r)]["region"].apply(
                    lambda x: one_hot(states, city_idx[x])
                )
            )[0]
            # for s in train_seasons
            for r in city_idx.keys()
        ]
    )

    x_test = np.array(
        [
            np.array(df[(df["epiweek"] == ew.week) & (df["region"] == r)][include_col])
            for r in city_idx.keys()
        ],
        dtype="float32",
    )

    region_test = np.array(
        [
            np.stack(
                df[(df["epiweek"] == ew.week) & (df["region"] == r)]["region"].apply(
                    lambda x: one_hot(states, city_idx[x])
                )
            )[0]
            for r in city_idx.keys()
        ]
    )

    static_test = np.array(
        [
            np.array(df_static[(df_static['STATEAbbrv'] == r)][include_col_static])
            for r in [ # get regions from the other dataframe
                df[(df["epiweek"] == ew.week) & (df["region"] == r)]["region"].iloc[0] for r in city_idx.keys()
                ]
        ],
        dtype="float32",
    ).squeeze()

    
    y_test = np.array(
        [
            np.array(df[(df["epiweek"] >= ew.week) & (df["region"] == r)]["target_death"])
            # for week in train_seasons
            for r in city_idx.keys()
        ],
        dtype="float32",
    )

    def create_dataset(full_region, full_meta, full_x, full_y, week_ahead=4):
        """
            NOTE: Adapt to handle 4-wk ahead at the same time. 
        """
        regions, metas, seqs, y = [], [], [], []
        for region, meta, seq_x, seq_y in zip(full_region, full_meta, full_x, full_y):
            for i in range(len(seq_x) - week_ahead):
                regions.append(region)
                metas.append(meta)
                seqs.append(seq_x[: i + 1])
                y.append(seq_y[i + week_ahead])
        return np.array(regions, dtype="float32"), np.array(metas, dtype="float32"), seqs, np.array(y, dtype="float32")

    train_region, train_static, train_x, train_y = create_dataset(region_train, static_train, x_train, y_train, wk_ahead)
    test_region, test_static, test_x, test_y = region_test, static_test, x_test, y_test[:,wk_ahead] 

    def create_tensors(regions, metas, seqs, ys):
        """
            ys: change to handle two dim
        """
        regions = float_tensor(regions)
        metas = float_tensor(metas)
        ys = float_tensor(ys)
        max_len = max([len(s) for s in seqs])
        out_seqs = np.zeros((len(seqs), max_len, seqs[0].shape[-1]), dtype="float32")
        lens = np.zeros(len(seqs), dtype="int32")
        for i, s in enumerate(seqs):
            out_seqs[i, : len(s), :] = s
            lens[i] = len(s)
        out_seqs = float_tensor(out_seqs)
        return regions, metas, out_seqs, ys, lens


    def create_mask(lens, out_dim=40):
        ans = np.zeros((max(lens), len(lens), out_dim), dtype="float32")
        for i, j in enumerate(lens):
            ans[j - 1, i, :] = 1.0
        return float_tensor(ans)

    train_region, train_static, train_x, train_y, train_lens = create_tensors(train_region, train_static, train_x, train_y)
    test_region, test_static, test_x, test_y, test_lens = create_tensors(test_region, test_static, test_x, test_y)
    test_lens = np.ones_like(test_lens) * (train_lens.max() + 1)
    train_dyn_x=train_x[:,:,-5].unsqueeze(2)  # see include_col index
    test_dyn_x=test_x[:,:,-5].unsqueeze(2)


    def scale_target(train_y,train_lens):
        """
            Scale target per region
            Assumes index in city_idx is in order, 
            i.e. if there are three regions, index goes from 0 to 2 
        """
        from sklearn.preprocessing import StandardScaler, PowerTransformer
        scaler_dict = {}
        seq_len = max(train_lens)
        new_train_y=[]
        for r,r_counter in city_idx.items():
            scaler = StandardScaler()
        # true_train_y = train_y.detach().clone()
            temp_y = scaler.fit_transform(
                train_y[
                    r_counter*seq_len:(r_counter+1)*seq_len
                ].cpu().numpy().reshape(-1,1)
                )
            # save scaler
            scaler_dict[r] = scaler
            new_train_y.append(temp_y)
        train_y = np.array(new_train_y,dtype="float32")
        train_y = torch.from_numpy(train_y).reshape(-1,1).to(device)
        return train_y, scaler_dict

    def inv_scale_target(preds,scaler_dict,lens):
        """
            This also works for 
            @param preds: array
            @param lens: 
        """
        seq_len = max(lens)  # only
        new_preds=[]
        for r,r_counter in city_idx.items():
            scaler = scaler_dict[r]
            temp_y = scaler.inverse_transform(
                preds[
                    r_counter*seq_len:(r_counter+1)*seq_len
                ].cpu().detach().numpy().reshape(-1,1)
                )
            new_preds.append(np.array(temp_y))
        
        preds = np.array(new_preds,dtype="float32")
        return preds

    if SCALE_TARGET:
        train_y, scaler_dict = scale_target(train_y,train_lens)

    """
        Create models
    """
    ENCODER_SIZE=64
    BIDIRECTIONAL=True
    gru_layers=2

    # encoder for covid signals
    encoder = Encoder(
        dim_seq_in=train_x.shape[-1], 
        # dim_metadata=3, 
        # dim_out=32, 
        n_layers=gru_layers, # Harsha set it to 2
        bidirectional=BIDIRECTIONAL,
        rnn_out=ENCODER_SIZE
    ).to(device)

    # encoder for segmented target
    dynamic_encoder = Encoder(
        dim_seq_in=1, # TODO: change here
        n_layers=gru_layers, 
        bidirectional=BIDIRECTIONAL,
        rnn_out=ENCODER_SIZE,
        clustering=True,
    ).to(device)

    # regional autoencoder
    region_ae = LinearAutoEncoder(
        dim_in=train_region.shape[-1],
        dim_hidden_ae=32,
        categorical=True
    ).to(device)

    # static regional data autoencoder
    static_ae = LinearAutoEncoder(
        dim_in=train_static.shape[-1],
        dim_hidden_ae=32,
        clustering=True,
    ).to(device)

    # decoder for prediction, attention not yet implemented
    decoder = AttDecoder(
        dim_in=train_x.shape[-1] + train_region.shape[-1] + train_static.shape[-1], 
        dim_region_emb=32,
        dim_encoder = ENCODER_SIZE,
        dim_out=1, # prediction 
        n_layers=gru_layers, 
        bidirectional=BIDIRECTIONAL,
        rnn_out=32,
    ).to(device)


    def save_model(file_prefix: str):
        torch.save(encoder.state_dict(), file_prefix + "_encoder.pth")
        torch.save(dynamic_encoder.state_dict(), file_prefix + "_dyn_encoder.pth")
        torch.save(region_ae.state_dict(), file_prefix + "_region_ae.pth")
        torch.save(static_ae.state_dict(), file_prefix + "_static_ae.pth")
        torch.save(decoder.state_dict(), file_prefix + "_decoder.pth")

    def load_model(file_prefix: str):
        encoder.load_state_dict(torch.load(file_prefix + "_encoder.pth"))
        dynamic_encoder.load_state_dict(torch.load(file_prefix + "_dyn_encoder.pth"))
        region_ae.load_state_dict(torch.load(file_prefix + "_region_ae.pth"))
        static_ae.load_state_dict(torch.load(file_prefix + "_static_ae.pth"))
        decoder.load_state_dict(torch.load(file_prefix + "_decoder.pth"))

    optimizer = optim.Adam(
        list(encoder.parameters()) + 
        list(dynamic_encoder.parameters()) + 
        list(region_ae.parameters()) + 
        list(static_ae.parameters()) + 
        list(decoder.parameters())
        ,
        lr=1e-3,
    )

    optimizer1 = optim.Adam(
        list(encoder.parameters()) + 
        list(dynamic_encoder.parameters()) + 
        list(region_ae.parameters()) + 
        list(static_ae.parameters()) + 
        list(decoder.parameters())
        ,
        lr=1e-4,
    )

    optimizer2 = optim.Adam(
        list(encoder.parameters()) + 
        list(dynamic_encoder.parameters()) + 
        list(region_ae.parameters()) + 
        list(static_ae.parameters()) + 
        list(decoder.parameters())
        ,
        lr=1e-5,
    )

    def forward_pass(x,dyn_x,lens,region,static):
        """
            change of variable name pending
        """
        hidden_encoder, _ = encoder.forward(
            x,
            create_mask(lens, ENCODER_SIZE)
        )
        dynamic_emb, q_dyn = dynamic_encoder.forward(
            dyn_x,
            create_mask(lens, ENCODER_SIZE)
        )
        region_emb, region_recon, _ = region_ae.forward(
            region
        )
        static_emb, static_recon, q_static = static_ae.forward(
            static
        )
        if MODE=='OnlyGRU':  # do not use similarity embeddings
            dynamic_emb = torch.zeros_like(dynamic_emb)
            static_emb = torch.zeros_like(static_emb)

        pred = decoder.forward(
            torch.cat([dynamic_emb, region_emb, static_emb], dim=1),
            hidden_encoder,
            region_emb,
            k_ahead=1
        )
        return pred, region_recon, static_recon, dynamic_emb, q_static, q_dyn

    """
        Train
    """
    N=2000
    if TRAIN:
        encoder.train()
        dynamic_encoder.train()
        region_ae.train()
        static_ae.train()
        decoder.train()
        losses = []
        best_loss_ = np.inf
        
        for ep in range(N):
            # print(f"Epoch: {ep+1}")
            if ep<N/3:
                optimizer.zero_grad()
            if ep<2*N/3:
                optimizer1.zero_grad()
            else:
                optimizer2.zero_grad()

            pred, region_recon, static_recon, dynamic_emb,  q_static, q_dyn = forward_pass(train_x,train_dyn_x,train_lens,train_region,train_static)
            loss = 2*F.mse_loss(pred.squeeze(2),train_y) + F.mse_loss(region_recon,train_region) 
            if MODE!='OnlyGRU':
                p_static=target_distribution(q_static)
                p_dyn=target_distribution(q_dyn)
                kl_static = F.kl_div(q_static.log(), p_static.detach())
                kl_dyn = F.kl_div(q_dyn.log(), p_dyn.detach())
                loss += kl_static + kl_dyn + F.mse_loss(static_recon,train_static)
            loss.backward()
            if ep<N/3:
                optimizer.step()
            if ep<2*N/3:
                optimizer1.step()
            else:
                optimizer2.step()

            loss_ = loss.detach().cpu().numpy()
            if ep > N-50 and loss_ < best_loss_:
                save_model(MODEL_PATH+str(ew)+'_'+str(wk_ahead)+'wk')
                best_loss_ = loss_
            losses.append(loss_)

    # predict on train
    load_model(MODEL_PATH+str(ew)+'_'+str(wk_ahead)+'wk')
    encoder.eval()
    dynamic_encoder.eval()
    region_ae.eval()
    static_ae.eval()
    decoder.eval()
    # print('train_y',train_y)
    preds, _, _, _, _, _ = forward_pass(train_x,train_dyn_x,train_lens,train_region,train_static)
    if SCALE_TARGET:
        preds = inv_scale_target(preds,scaler_dict,train_lens)

    # predict on test
    print('test_y',test_y)
    preds, _, _, _, _, _ = forward_pass(test_x,test_dyn_x,test_lens,test_region,test_static)
    if SCALE_TARGET:
        preds = inv_scale_target(preds,scaler_dict,[1])  # [1] is needed as train_lens only for test with one obs
        print('pred test',preds.reshape(-1))
    else:
        print('pred',preds.reshape(-1))

    test_y=test_y.detach().cpu().numpy()
    mae_us = np.abs(preds[city_idx['X']].reshape(-1) - test_y[city_idx['X']].reshape(-1)).mean()
    mae_ca = np.abs(preds[city_idx['CA']].reshape(-1) - test_y[city_idx['CA']].reshape(-1)).mean()
    mae_ga = np.abs(preds[city_idx['GA']].reshape(-1) - test_y[city_idx['GA']].reshape(-1)).mean()
    mae_tx = np.abs(preds[city_idx['TX']].reshape(-1) - test_y[city_idx['TX']].reshape(-1)).mean()
    mae_pa = np.abs(preds[city_idx['PA']].reshape(-1) - test_y[city_idx['PA']].reshape(-1)).mean()
    print('=================================')
    print('week',ew)
    print('mae')
    print(mae_us,mae_ca,mae_ga,mae_tx,mae_pa,mae_overall)
    mae_dict[str(ew)] = [mae_us,mae_ca,mae_ga,mae_tx,mae_pa]
    print('=================================')




def get_epiweeks_list(start_ew,end_ew):
    """
        returns list of epiweeks objects between start_ew and end_ew (inclusive)
        this is useful for iterating through these weeks
    """
    iter_weeks = list(Year(2020).iterweeks())
    idx_start = iter_weeks.index(start_ew)
    idx_end = iter_weeks.index(end_ew)
    return iter_weeks[idx_start:idx_end+1]


start_ew = Week.fromstring(start_ew)
end_ew = Week.fromstring(end_ew)
iter_weeks = get_epiweeks_list(start_ew,end_ew)



for ew in iter_weeks:
    train_week(ew,MODE)

mae_list = []
for ew in iter_weeks:
    mae_list.append(mae_dict[str(ew)])
print(mae_list)
mae_mean = np.array(mae_list).mean(0)
print('mae_mean',mae_mean)